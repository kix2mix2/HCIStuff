package com.example.cristina.tipcalculatorandroid;

import android.content.Intent;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.SeekBar.OnSeekBarChangeListener;


public class MainActivity extends AppCompatActivity {

    TipCalculatorModel tipCalc;
    TextView billLabel;
    TextView tipLabel;
    SeekBar tipSlider;
    EditText billNumber;

    public final static String EXTRA_MESSAGE = "com.example.tipcalculatorandroid.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);

        //initialize view in the UI
        initializeVariables();

        tipLabel.setText("Tip Percentage: (" + tipSlider.getProgress() + "%)" );
        billNumber.setText("100");

        double tipPercentage = tipSlider.getProgress()/100;

        System.out.println("Input: "+ billNumber.getText());

        tipCalc = new TipCalculatorModel(Integer.parseInt(billNumber.getText().toString()), tipPercentage);

        tipSlider.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            int progress = 0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progresValue, boolean fromUser) {
                progress = progresValue;
                tipLabel.setText("Tip Percentage: (" + progress + "%)" );
                tipCalc.setTip((double)progress/100);
                Toast.makeText(getApplicationContext(), "Changing seekbar's progress", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }

        });

    }

    private void initializeVariables() {
        billLabel = (TextView) findViewById(R.id.billLabel);
        tipLabel = (TextView) findViewById(R.id.tipLabel);
        tipSlider = (SeekBar) findViewById(R.id.tipSlider);
        billNumber = (EditText) findViewById(R.id.billNumber);
    }

    public void calculateTapped(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, SuccessActivity.class);
        tipCalc.setBill(Integer.parseInt(billNumber.getText().toString()));
        System.out.println("TipCalc: " + tipCalc.getBill() + " " + tipCalc.getTip() + " " + tipCalc.getTotal());


        String message = String.valueOf(tipCalc.getTotal());
        intent.putExtra(EXTRA_MESSAGE, message);

        startActivity(intent);

    }
}
