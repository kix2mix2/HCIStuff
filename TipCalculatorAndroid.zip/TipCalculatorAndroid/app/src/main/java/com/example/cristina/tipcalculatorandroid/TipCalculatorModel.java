package com.example.cristina.tipcalculatorandroid;

/**
 * Created by cristina. on 14/04/16.
 */
public class TipCalculatorModel {


    public double getBill() {
        return bill;
    }

    public void setBill(double bill) {
        this.bill = bill;
    }

    private double bill;

    public double getTip() {
        return tip;
    }

    public void setTip(double tip) {
        this.tip = tip;
    }

    private double tip;

    public double getTotal() {
        total = bill + bill*tip ;
        return total;
    }

    private double total;


    public TipCalculatorModel(double bill, double tip) {
        this.bill = bill;
        this.tip = tip;
        this.total = bill + bill*tip ;
    }



}
